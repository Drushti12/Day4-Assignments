create procedure EmployeeDetails @deptname varchar(20)
as
begin
select e.id,e.name,e.salary from employeeTable e inner join departmentTable d on departmentno=deptid 
where deptname=@deptname
end