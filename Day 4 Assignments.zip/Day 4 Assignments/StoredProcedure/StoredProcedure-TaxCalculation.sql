create procedure TaxCalculation
as
begin
select name,salary,departmentno,(salary*0.05) as TaxAmount from employeeTable;
end;